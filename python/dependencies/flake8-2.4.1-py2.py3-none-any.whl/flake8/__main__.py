from flake8.main import main

# python -m flake8 (with Python >= 2.7)
main()
